SMODS.Atlas {
    key = "gay",
    path = "gay.png",
    px = 71,
    py = 95
}