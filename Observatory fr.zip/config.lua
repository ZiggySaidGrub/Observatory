return {
    ["next_id"] = 0,
    ["play_order"] = {},
    ["shop_order"] = {},
    ["play_swap"] = false,
    ["shop_swap"] = false
}